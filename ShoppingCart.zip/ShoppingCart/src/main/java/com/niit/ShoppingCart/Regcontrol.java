package com.niit.ShoppingCart;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.model.Register;

@Controller
@RequestMapping("/Register")
public class Regcontrol{
	 @RequestMapping(method = RequestMethod.GET)
     public String viewRegister(Map<String, Object> model) {
       Register userForm = new Register();    
       model.put("userForm", userForm);
      
        
       return "register";
   } 
	
	 
	
	 @RequestMapping(method = RequestMethod.POST)
	    public String processRegister(@ModelAttribute("userForm") Register user,
	            Map<String, Object> model) {
	         
	        
	        System.out.println("First Name: " + user.getFirstname());
	        System.out.println("Last Name: " + user.getLastname());
	        System.out.println("password: " + user.getPassword());
	        System.out.println("email: " + user.getEmail());
	        System.out.println("mobile no: " + user.getMobileno());
	        
	         
	        return "Result";
	    }
}

    
	

