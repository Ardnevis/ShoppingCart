package com.niit.ShoppingCart;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Homecontroller {

	@RequestMapping("/")
	public String index()
	{
	return "index";
	}	
	@RequestMapping("/login")
	   public String login(Model model)
	   {
	   model.addAttribute("isuserclickedlogin", "true");
	     return "login";
       }
	@RequestMapping("/register")
	   public String register(Model model)
	   {
	   model.addAttribute("isuserclickedregister", "true");
	     return "register";
    }
	
	@RequestMapping("/Home")
	   public String Home(Model model)
	   {
	   model.addAttribute("isuserclickedHome", "true");
	     return "index";
 }
	@RequestMapping("/About")
	   public String About(Model model)
	   {
	   model.addAttribute("isuserclickedAbout", "true");
	     return "About";
}
	@RequestMapping("/contact us")
	   public String contact(Model model)
	   {
	   model.addAttribute("isuserclickedcontactus", "true");
	     return "contact us";
   }
	@RequestMapping("/products")
	   public String products(Model model)
	   {
	   model.addAttribute("isuserclickedproducts", "true");
	     return "index";
}
	@RequestMapping("/Result")
	   public String result(Model model)
	   {
	   model.addAttribute("isuserclickedResult", "true");
	     return "Result";
}
}