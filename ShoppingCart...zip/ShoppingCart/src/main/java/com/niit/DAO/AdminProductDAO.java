package com.niit.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.niit.model.AdminProductmodel;

@Repository
public class AdminProductDAO {
	@Autowired
	SessionFactory sessionFactory;
	public void Save(AdminProductmodel pro)
	{
		System.out.println("in Product Dao1");
		Session session= sessionFactory.openSession();
		System.out.println("insert method called");
		session.beginTransaction();
		session.save(pro);
		session.getTransaction().commit();
		session.close();
		System.out.println("in adProduct Dao2");
	}
	public String list()
	{
		System.out.println("in adProduct listproduct1");
		Session se= sessionFactory.openSession();
		se.beginTransaction();
		List li=se.createQuery("from AdminProductmodel").list();
		Gson gson = new Gson();
		
		String jsonprolist=gson.toJson(li);
		se.getTransaction().commit();
		se.close();
		System.out.println("in adProduct list product2");
		return jsonprolist ;
	}
	public void deletePro(String pid)
	{
		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 AdminProductmodel pro=(AdminProductmodel)se.get(AdminProductmodel.class,pid);
		se.delete(pro);
		se.getTransaction().commit();
		se.close();
	}
	public void updatePro(AdminProductmodel uprd)
	{
		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 String pid=uprd.getPid();
		 AdminProductmodel adobj=(AdminProductmodel)se.get(AdminProductmodel.class,pid);
		adobj.setPdescription(uprd.getPdescription());
		adobj.setPname(uprd.getPname());
		adobj.setPprice(uprd.getPprice());
		adobj.setCid(uprd.getCid());
		adobj.setPstock(uprd.getPstock());
		adobj.setSid(uprd.getSid());
		se.update(adobj);
		 se.getTransaction().commit();
	
		 se.close();
	}
	public AdminProductmodel DispRecord(String pid)
	{
		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 AdminProductmodel adpd=(AdminProductmodel)se.get(AdminProductmodel.class,pid);
		return adpd;
	}
}