package com.niit.DAO;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;

import com.niit.model.AdminSuppliermodel;
@Repository
public class AdminSupplierDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public AdminSupplierDAO(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	public boolean save(AdminSuppliermodel c) {
		try {
			

			System.out.println("in supplier Dao1");
			Session session= sessionFactory.openSession();
			System.out.println("insert method called");
			session.beginTransaction();
			session.save(c);
			session.getTransaction().commit();
			session.close();
			System.out.println("in supplier Dao2");
			
//			ht.save(supplier);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean update(AdminSuppliermodel ap) {
		// TODO Auto-generated method stub
		

		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 String apid=ap.getSid();
		 AdminSuppliermodel adobj=(AdminSuppliermodel)se.get(AdminSuppliermodel.class, apid);
			adobj.setSname(ap.getSname());
			adobj.setSaddress(ap.getSaddress());
			se.update(adobj);
		 se.getTransaction().commit();
	
		 se.close();
		return false;
	}

	public boolean delete(String sid) {
		// TODO Auto-generated method stub

		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 System.out.println("before command");
		 AdminSuppliermodel adp=(AdminSuppliermodel)se.get(AdminSuppliermodel.class,sid);
		 System.out.println("before delete");
		se.delete(adp);
		 System.out.println("AFTER DELETE");
		se.getTransaction().commit();
		se.close();
		
		
		
		return false;
	}


	public String list() {
		// TODO Auto-generated method stub
		
		
		Session se= sessionFactory.openSession();
		se.beginTransaction();
		List li=se.createQuery("from AdminSuppliermodel").list();
			Gson gson = new Gson();
	
		String jsonsuplist=gson.toJson(li);
		se.getTransaction().commit();
		se.close();
		System.out.println("in adProduct listttttproduct2");
		return jsonsuplist ;
		}

	public String sortId() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();

		Query query = session.createQuery("from AdminSuppliermodel order by sid DESC");
		query.setMaxResults(1);
		AdminSuppliermodel last = (AdminSuppliermodel) query.uniqueResult();
		String id=last.getSid();
		System.out.println("last column product id "+id);
		return id;
	}

	
	public  AdminSuppliermodel DispRecord(String pid) {
		// TODO Auto-generated method stub
		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 AdminSuppliermodel adpd=(AdminSuppliermodel)se.get(AdminSuppliermodel.class,pid);
		return adpd;
	}

	public AdminSuppliermodel get(String id) {
		// TODO Auto-generated method stub
		return null;
	}
}