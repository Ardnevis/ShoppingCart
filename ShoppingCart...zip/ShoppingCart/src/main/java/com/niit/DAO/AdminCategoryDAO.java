package com.niit.DAO;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.niit.model.AdminCategorymodel;
@Repository
public class AdminCategoryDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public AdminCategoryDAO(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}

	public boolean save(AdminCategorymodel category) {
		try {
			

			System.out.println("in category Dao1");
			Session session= sessionFactory.openSession();
			System.out.println("insert method called");
			session.beginTransaction();
			session.save(category);
			session.getTransaction().commit();
			session.close();
			System.out.println("in categoryt Dao2");
			
//			ht.save(category);
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean update(AdminCategorymodel cid) {
		// TODO Auto-generated method stub
		

		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 String apid=cid.getCid();
		 AdminCategorymodel adobj=(AdminCategorymodel)se.get(AdminCategorymodel.class, apid);
			adobj.setCname(cid.getCname());//get what are need to be updates here only name   i have taken
			adobj.setCdescription(cid.getCdescription());
			se.update(adobj);
		 se.getTransaction().commit();
	
		 se.close();
		return false;
	}

	public boolean delete(String cid) {
		// TODO Auto-generated method stub

		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 System.out.println("before command");
		 AdminCategorymodel adp=(AdminCategorymodel)se.get(AdminCategorymodel.class,cid);
		 System.out.println("before delete");
		se.delete(adp);
		 System.out.println("AFTER DELETE");
		se.getTransaction().commit();
		se.close();
		
		
		
		return false;
	}


	public String list() {
		// TODO Auto-generated method stub
		
		
		Session se= sessionFactory.openSession();
		se.beginTransaction();
		List li=se.createQuery("from AdminCategorymodel").list();
			Gson gson = new Gson();
	
		String jsonprodlist=gson.toJson(li);
		se.getTransaction().commit();
		se.close();
		System.out.println("in adProduct listttttproduct2");
		return jsonprodlist ;
	
//		String s=ht.loadAll(CategoryModel.class);

//		Session session=sessionFactory.openSession();
//
//		Query query = session.createQuery("from AdminProduct order by aproductId DESC");
//		query.setMaxResults(1);
//		AdminProduct last = (AdminProduct) query.uniqueResult();
//		int id=last.getAproductId();
//		System.out.println("last column product id "+id);
	
	}

	public String sortId() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();

		Query query = session.createQuery("from AdminCategorymodel order by cid DESC");//hql query
		query.setMaxResults(1);
		AdminCategorymodel last = (AdminCategorymodel) query.uniqueResult();
		String id=last.getCid();
		System.out.println("last column product id "+id);
		return id;
	}

	
	public  AdminCategorymodel DispRecord(String pid) {
		// TODO Auto-generated method stub
		Session se=sessionFactory.openSession();
		 se.beginTransaction();
		 AdminCategorymodel adpd=(AdminCategorymodel)se.get(AdminCategorymodel.class,pid);
		return adpd;
	}

	public AdminCategorymodel get(String id) {
		// TODO Auto-generated method stub
		return null;
	}
}