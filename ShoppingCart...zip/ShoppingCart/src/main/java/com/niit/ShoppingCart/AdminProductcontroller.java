package com.niit.ShoppingCart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.DAO.AdminCategoryDAO;
import com.niit.DAO.AdminProductDAO;
import com.niit.DAO.AdminSupplierDAO;
import com.niit.model.AdminProductmodel;

@Controller
public class AdminProductcontroller {
	@Autowired
	AdminCategoryDAO catDao;
	@Autowired
	AdminSupplierDAO supDao;
	@Autowired
	AdminProductDAO prodDao;
	
	@RequestMapping(value="/Adminproduct",method=RequestMethod.GET)
	public ModelAndView showProduct()
	{
		ModelAndView mv = new ModelAndView("Adminproduct","AdminProductmodel",new AdminProductmodel());
	    String catjsonlist=catDao.list();
	    mv.addObject("data",catjsonlist);
	    
	    String supjsonlist=supDao.list();
	    mv.addObject("data2",supjsonlist);
	    String prod=prodDao.list();
	    mv.addObject("data3",prod);
	    mv.addObject("check", true);
	    return mv;    
	}
	@RequestMapping(value="/addpro",method=RequestMethod.POST)
	public ModelAndView addpro(AdminProductmodel aprod)
	{
		System.out.println("in addAdminProduct post1");
	    prodDao.Save(aprod); 
		System.out.println("in addAdminProduct post2");
		String prd=prodDao.list();
		ModelAndView mv = new ModelAndView("Adminproduct","AdminProductmodel",new AdminProductmodel());
		mv.addObject("data3",prd);
		String catjsonlist=catDao.list();
		
		mv.addObject("data",catjsonlist);
		System.out.println("in addAdminProduct post3");
		String supjsonlist=supDao.list();
		System.out.println("in addAdminProduct post4");
		mv.addObject("data2",supjsonlist);
		mv.addObject("check",true);
		System.out.println("in addAdminProduct post5");
		
		System.out.println("in addAdminProduct post6"+prd);
		
		System.out.println("in addAdminProduct post7");
		 return mv;
		
	}
	@RequestMapping(value="/deletepro",method = RequestMethod.GET)
	public ModelAndView deletePro(@RequestParam("pid")String pid)
	{
		prodDao.deletePro(pid);
		String prjson=prodDao.list();
		ModelAndView m =new ModelAndView("Adminproduct","AdminProductmodel",new AdminProductmodel());
		m.addObject("check",true);
		m.addObject("data3",prjson);
	
		String catjsonlist=catDao.list();
		
		m.addObject("data", catjsonlist);
		String supjsonlist=supDao.list();
		m.addObject("data2", supjsonlist);
		return m;
		
	}
	@RequestMapping(value="/updatepro",method=RequestMethod.GET)
	public ModelAndView updatePro(@RequestParam("pid")String pid)
	{
		AdminProductmodel ad =prodDao.DispRecord(pid);
		ModelAndView m = new ModelAndView("Adminproduct","AdminProductmodel",ad);
		

		System.out.println("pro idddddddddddddddddddddd"+ad.getPid());
		m.addObject("check",false);
		String catjsonlist=catDao.list();
		
		m.addObject("data",catjsonlist);
		String supjsonlist=supDao.list();
		m.addObject("data2",supjsonlist);
		String pdjsonlist=prodDao.list();
		m.addObject("data3",pdjsonlist);
		System.out.println(supjsonlist);
		return m;
	}
	@RequestMapping(value="/Updatepro",method=RequestMethod.POST)
	public ModelAndView updateProd(AdminProductmodel pd)
	{
		prodDao.updatePro(pd);
		String apdjsonlist=prodDao.list();
		ModelAndView m = new ModelAndView("Adminproduct","AdminProductmodel",new AdminProductmodel());
		m.addObject("check",true);
		m.addObject("data3",apdjsonlist);
		String catjsonlist=catDao.list();
		
		
		
		m.addObject("data",catjsonlist);
		String supjsonlist=supDao.list();
		m.addObject("data2",supjsonlist);
	
		
		
		return m;
		
	}
	
	
	
}
	